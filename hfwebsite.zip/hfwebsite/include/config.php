<?php
$con=mysqli_connect('localhost','root','','hfdatabase')or die(mysqli_error());

?>