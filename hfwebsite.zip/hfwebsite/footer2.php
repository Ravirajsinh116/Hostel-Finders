<!-- BEGIN FOOTER -->
<footer>
  <div class="footer-container">
    <div class="container">
      <!-- Footer box -->
      <div class="footer-top">
        <div class="row">
          <div class="span4">
            <h3>contact detail</h3>
            <p><span>Phone. 762XXXXXXX </span><br/><span>Mail. <a href="mailto:hostelfinders19.com?Subject=Hello%20again">hostelfinders19@gmail.com</a></span><br/></p>
          </div>
          <div class="span4">
            <h3>Useful links</h3>
            <ul>
              <li><a href="index2.php" title="">Home Page</a></li>
              <li><a href="about_us2.php" title="">Who we are</a></li>
              <li><a href="contact2.php" title="">Contact Us</a></li>
            </ul>
          </div>
            <!-- <div class="span4">
              <h3>don’t miss out</h3>
              <p>In venenatis neque a eros laoreet eu placerat erat suscipit. Fusce cursus, erat ut scelerisque condimentum, quam odio ultrices leo.</p>
              <div class="newletter">
                <form>
                  <input type="text" class="textnewletter" placeholder="Enter your email here…">
                  <button type="submit" class="buttonnewletter">Submit</button>
                </form>
              </div>
            </div> -->
        </div>
      </div>
      <!-- End footer box -->
      
      <!-- <div class="footer-bottom">
        <div class="row">
          <div class="span6">
            <p>Copyright © 2013 PGL RealEstast. Designed by <a href="#" title="">PixelGeekLab</a><br/>All rights reserved.</p>
          </div>
          <div class="span6">
            <div class="social">
              <ul>
                <li><a class="facebook" title="" href="#"> Facebook </a></li>
                <li><a class="twitter" title="" href="#"> twitter </a></li>
                <li><a class="googplus" title="" href="#"> googplus </a></li>
                <li><a class="pinterest" title="" href="#"> pinterest </a></li>
                <li><a class="email" title="" href="#"> Email </a></li>
                <li><a class="feed" title="" href="#"> Feed </a></li>
              </ul>
            </div>
          </div>
        </div>
      </div> -->
    </div>
  </div>
</footer>
<!-- END FOOTER -->
<!-- END FOOTER -->
<div id='bttop'>BACK TO TOP</div>