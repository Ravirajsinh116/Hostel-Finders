<?php
include('header.php')

?>
      <div class="row-fluid">

	  <!-- Banner -->

       <div class="row-fluid">

        <div class="span12">

          <section class="pic-cat">

          <img  src="img/imgdemo/1900x200b.png" />

          </section>

        </div>

      </div>

		<!-- End banner -->

      </div>

    </header>

	<!-- END HEADER  -->

	

	<!-- BEGIN CONTENT -->

    <div class="main-content">

      <div class="properties">

        <div class="container">

          <div class="grid_full_width">

			<!-- About US -->

            <div class="about_us">

              
              <div class="welcome">
                <div class="row">
                  <div class="span6">
                    <div class="picct">
                      <img src="img/Hostel15.png" />
                    </div>
                  </div>
                  <br>
                  <div class="span6">
                      <div class="textct">
                        <h2>Welcome to HOSTELFINDERS!</h2>
                        <h6>
                        Looking at a property listing website that will effectively help you to find Hostels in your area? 
                        Wondering where to Rent your property? Join HOSTELFINDERS.com,
                         a free property listing site wherein you can find property as per requirements, And post free property ads online to list property for rent.
                        All you need to do is furnish a comprehensive property list with accurate and relevant details of your property.
</h6>
                        
                      </div>
                  </div>
                </div>
              </div>

              <!-- <div class="choseus">
                <div class="row">
                  <div class="span6">
                     <h4>Why choose us?</h4>
                       <div class="showhideabout">

                <ul>
                  <li>

                    <span class="btshowhide" id="fag1" rel="1">Excellent Support</span>
                    <div class="abouttext class1">
                      Donec risus nulla, fringilla a rhoncus vitae, semper a massa. Vivamus ullamcorper, enim sit amet consequat laoreet, tortor tortor dictum urna, ut egestas urna ipsum nec libero. 
                    </div>


                  </li>
                  <li>
                    <span class="btshowhide" id="fag2" rel="2"> Easy To Customize </span>
                    <div class="abouttext class2">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam obcaecati architecto sequi nisi fuga rerum quam cum reprehenderit distinctio doloremque iste officia deleniti nostrum ducimus aliquid sed provident doloribus animi.
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam obcaecati architecto sequi nisi fuga rerum quam cum reprehenderit distinctio doloremque iste officia deleniti nostrum ducimus aliquid sed provident doloribus animi.
                    </div>
                  </li>
                  <li>
                    <span class="btshowhide" id="fag3" rel="3">SEO Optimized </span>
                    <div class="abouttext class3">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam obcaecati architecto sequi nisi fuga rerum quam cum reprehenderit distinctio doloremque iste officia deleniti nostrum ducimus aliquid sed provident doloribus animi.
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam obcaecati architecto sequi nisi fuga rerum quam cum reprehenderit distinctio doloremque iste officia deleniti nostrum ducimus aliquid sed provident doloribus animi.
                    </div>
                  </li>
                </ul>
              </div>
                  </div>
              </div> -->
              
             

            </div>

			<!-- End About US -->

			

          </div>

        </div>

      </div>

    </div>

	<!-- END CONTENT -->

	

  <?php
include('footer.php')
?>
  <!-- Always latest version of jQuery-->

  <script src="js/jquery-1.8.3.min.js"></script>

  <script src="js/bootstrap.min.js"></script>

  <!-- Some scripts that are used in almost every page -->

  <script src="js/tinynav/tinynav.js" type="text/javascript"></script>

  <script type="text/javascript" src="js/tabber/tabber.js"></script>

  <!-- Load template main javascript file -->

  <script type="text/javascript" src="js/main.js"></script>
  <script type="text/javascript">

/* <![CDATA[ */

jQuery(function(){
  $('.abouttext').hide();
  jQuery('.btshowhide').click(function(e){
    e.preventDefault();
    var target = jQuery('.class' + jQuery(this).attr('rel'));
    jQuery('.abouttext').not(target).hide();
    target.show();
    jQuery('.btshowhide').not(this).removeClass("active");
    jQuery(this).addClass("active");
  })
});



/* ]]> */

</script>

  </body>

</html>



